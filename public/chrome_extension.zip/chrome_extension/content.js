// ── CyberShield 360 – Content Script ──
// Runs on every page to inspect DOM for phishing indicators.

(function () {
  "use strict";

  // Known brands and their legitimate domains
  const BRAND_DOMAINS = {
    "instagram": ["instagram.com"],
    "facebook": ["facebook.com", "fb.com"],
    "google": ["google.com", "accounts.google.com"],
    "paypal": ["paypal.com"],
    "apple": ["apple.com", "appleid.apple.com"],
    "microsoft": ["microsoft.com", "login.microsoftonline.com", "live.com"],
    "amazon": ["amazon.com", "amazon.in", "amazon.co.uk"],
    "netflix": ["netflix.com"],
    "twitter": ["twitter.com", "x.com"],
    "linkedin": ["linkedin.com"],
    "github": ["github.com"],
    "yahoo": ["yahoo.com"],
    "dropbox": ["dropbox.com"],
    "spotify": ["spotify.com"],
    "whatsapp": ["whatsapp.com", "web.whatsapp.com"],
    "telegram": ["telegram.org", "web.telegram.org"],
    "snapchat": ["snapchat.com"],
    "tiktok": ["tiktok.com"],
    "steam": ["steampowered.com", "store.steampowered.com"],
    "roblox": ["roblox.com"],
    "discord": ["discord.com"],
    "twitch": ["twitch.tv"]
  };

  // Phrases that indicate legitimate third-party usage, not impersonation
  const LEGIT_PHRASES = [
    "sign in with google", "log in with google", "continue with google",
    "sign in with facebook", "log in with facebook", "continue with facebook",
    "sign in with apple", "log in with apple", "continue with apple",
    "sign in with microsoft", "continue with microsoft",
    "sign in with github", "log in with github", "continue with github",
    "sign in with twitter", "sign in with x",
    "sign in with linkedin", "sign in with discord",
    "powered by google", "google analytics", "google ads", "google maps",
    "google fonts", "google translate", "google play", "google cloud",
    "powered by facebook", "facebook pixel", "facebook sdk",
    "powered by microsoft", "microsoft teams",
    "available on the app store", "get it on google play"
  ];

  function detectBrandImpersonation() {
    const hostname = location.hostname.toLowerCase();

    // If the current site IS a known legitimate brand, never flag it
    const allLegitDomains = Object.values(BRAND_DOMAINS).flat();
    const siteIsLegit = allLegitDomains.some(
      (d) => hostname === d || hostname.endsWith("." + d)
    );
    if (siteIsLegit) return null;

    const hasLogin = document.querySelectorAll('input[type="password"]').length > 0;
    if (!hasLogin) return null; // no login form → can't be a phishing login page

    const title = document.title.toLowerCase();
    const bodyText = document.body.innerText.toLowerCase();
    const fullText = title + " " + bodyText;

    // If page uses legitimate OAuth phrases, don't flag that brand
    const legitBrands = new Set();
    for (const phrase of LEGIT_PHRASES) {
      if (fullText.includes(phrase)) {
        const brand = Object.keys(BRAND_DOMAINS).find((b) => phrase.includes(b));
        if (brand) legitBrands.add(brand);
      }
    }

    for (const [brand, legit] of Object.entries(BRAND_DOMAINS)) {
      if (legitBrands.has(brand)) continue;

      const regex = new RegExp("\\b" + brand + "\\b", "i");

      // The page title must claim to be the brand (strongest signal)
      const titleMatch = regex.test(title);

      // Or the page is dominated by the brand — many mentions + login form
      const bodyMatches = (fullText.match(new RegExp("\\b" + brand + "\\b", "gi")) || []).length;

      // Check for impersonation patterns like "Sign in to your [brand] account"
      const impersonationPhrases = [
        `sign in to ${brand}`, `log in to ${brand}`, `${brand} account`,
        `${brand} sign in`, `${brand} login`, `welcome to ${brand}`,
        `enter your ${brand}`, `${brand} password`
      ];
      const hasImpersonationPhrase = impersonationPhrases.some((p) => fullText.includes(p));

      if (hasImpersonationPhrase || (titleMatch && bodyMatches >= 2) || bodyMatches >= 5) {
        return brand.charAt(0).toUpperCase() + brand.slice(1);
      }
    }
    return null;
  }

  function detectSuspiciousForms() {
    const forms = [...document.querySelectorAll("form")];
    const hostname = location.hostname;
    let suspicious = false;

    for (const form of forms) {
      const action = (form.getAttribute("action") || "").toLowerCase();
      if (!action || action === "#" || action.startsWith("/") || action.startsWith("?")) continue;
      try {
        const actionHost = new URL(action, location.href).hostname;
        if (actionHost !== hostname) suspicious = true;
      } catch { /* ignore */ }
    }
    return suspicious;
  }

  function collectPageData() {
    const passwordFields = document.querySelectorAll('input[type="password"]');
    const loginForms = document.querySelectorAll(
      'form[action*="login"], form[action*="signin"], form[action*="auth"]'
    );

    return {
      hasPasswordField: passwordFields.length > 0 || loginForms.length > 0,
      formCount: document.querySelectorAll("form").length,
      externalScripts: [...document.querySelectorAll('script[src]')]
        .filter((s) => {
          try {
            return new URL(s.src).hostname !== location.hostname;
          } catch {
            return false;
          }
        }).length,
      impersonatedBrand: detectBrandImpersonation(),
      suspiciousFormAction: detectSuspiciousForms(),
      pageTitle: document.title
    };
  }

  // Listen for pre-load URL-only warning from background (fires before DOM is ready)
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "URL_PRE_CHECK" && message.result.score >= 7) {
      // Page hasn't loaded yet — wait for body then show overlay immediately
      if (document.body) {
        document.body.style.filter = "blur(4px)";
        document.body.style.pointerEvents = "none";
        showBlockingOverlay(message.result);
      } else {
        document.addEventListener("DOMContentLoaded", () => {
          document.body.style.filter = "blur(4px)";
          document.body.style.pointerEvents = "none";
          showBlockingOverlay(message.result);
        });
      }
    }
  });

  // Wait for DOM before collecting page data and doing full analysis
  function runFullAnalysis() {
    const data = collectPageData();
    chrome.runtime.sendMessage({
      type: "PAGE_DATA",
      url: location.href,
      data
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runFullAnalysis);
  } else {
    runFullAnalysis();
  }

  // Listen for full analysis result from background
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type !== "ANALYSIS_RESULT") return;

    const { result } = message;
    const existing = document.getElementById("cybershield-overlay");

    if (result.score >= 7 && !existing) {
      document.body.style.filter = "blur(4px)";
      document.body.style.pointerEvents = "none";
      showBlockingOverlay(result);
    } else if (result.score < 7 && existing) {
      // Pre-check was aggressive but full analysis says it's fine — remove overlay
      existing.remove();
      document.body.style.filter = "";
      document.body.style.pointerEvents = "";
    }
  });

  function showBlockingOverlay(result) {
    if (document.getElementById("cybershield-overlay")) return;

    const overlay = document.createElement("div");
    overlay.id = "cybershield-overlay";

    const reasonsHtml = result.reasons
      .map((r) => {
        const isApi = r.startsWith("⛔");
        const dotColor = isApi ? "#ef4444" : "#f59e0b";
        const titleColor = isApi ? "#ef4444" : "#1e293b";
        return `<li style="display:flex;align-items:flex-start;gap:12px;padding:8px 0;">
          <div style="width:8px;height:8px;border-radius:50%;background:${dotColor};margin-top:5px;flex-shrink:0;"></div>
          <span style="font-size:13px;font-weight:600;color:${titleColor};line-height:1.4;">${r}</span>
        </li>`;
      })
      .join("");

    // Risk bar segments
    const filled = Math.ceil(result.score / 2);
    const segColors = ["#22c55e", "#f59e0b", "#f97316", "#ef4444", "#dc2626"];
    const segHtml = Array.from({ length: 5 }, (_, i) => {
      const bg = i < filled ? segColors[i] : "#e2e8f0";
      const radius = i === 0 ? "6px 4px 4px 6px" : i === 4 ? "4px 6px 6px 4px" : "4px";
      return `<div style="flex:1;height:8px;border-radius:${radius};background:${bg};"></div>`;
    }).join("");

    overlay.innerHTML = `
      <div style="
        position:fixed;inset:0;z-index:2147483647;
        background:rgba(15,23,42,0.85);backdrop-filter:blur(4px);
        display:flex;align-items:center;justify-content:center;
        font-family:Inter,'Segoe UI',system-ui,-apple-system,sans-serif;
        pointer-events:auto;user-select:auto;
      ">
        <div style="
          background:#ffffff;border-radius:24px;
          padding:0;max-width:420px;width:92%;
          box-shadow:0 25px 50px rgba(0,0,0,0.25);overflow:hidden;
        ">
          <!-- Header -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:20px 24px 12px;">
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="background:#1d4ed8;padding:6px;border-radius:10px;display:flex;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                </svg>
              </div>
              <span style="font-size:18px;font-weight:700;color:#1e293b;">CyberShield <span style="color:#1d4ed8;">360</span></span>
            </div>
          </div>

          <!-- Threat Card -->
          <div style="padding:0 24px 8px;">
            <div style="background:#fef2f2;border-radius:24px;padding:32px;display:flex;flex-direction:column;align-items:center;text-align:center;border:1px solid rgba(239,68,68,0.12);">
              <div style="background:#fff;padding:16px;border-radius:50%;margin-bottom:16px;box-shadow:0 2px 8px rgba(0,0,0,0.06);">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
              </div>
              <h2 style="font-size:22px;font-weight:800;color:#1e293b;margin-bottom:8px;">Threat Detected</h2>
              <p style="font-size:13px;color:#64748b;line-height:1.5;max-width:280px;">
                We've found potential risks on this page that may compromise your privacy.
              </p>
            </div>
          </div>

          <!-- Domain -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 28px;">
            <span style="font-size:12px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;">Scanning</span>
            <span style="font-size:13px;font-weight:700;color:#1e293b;background:#f8fafc;padding:4px 12px;border-radius:8px;border:1px solid #e2e8f0;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${result.domain}</span>
          </div>

          <!-- Risk Bar -->
          <div style="padding:12px 28px 8px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
              <span style="font-size:12px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;">Site Risk Level</span>
              <span style="font-size:12px;font-weight:700;color:#ef4444;">High Risk</span>
            </div>
            <div style="display:flex;gap:4px;width:100%;margin-bottom:6px;">${segHtml}</div>
            <p style="font-size:12px;color:#94a3b8;font-style:italic;">
              Risk score: <span style="font-weight:700;color:#475569;font-style:normal;">${result.score} / 10</span>
            </p>
          </div>

          <!-- Security Report -->
          <div style="padding:8px 24px 12px;">
            <div style="background:#fff;border:1px solid #f1f5f9;border-radius:16px;padding:20px;box-shadow:0 1px 3px rgba(0,0,0,0.04);">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1d4ed8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
                <span style="font-size:13px;font-weight:700;color:#1e293b;">Security Report</span>
              </div>
              <ul style="list-style:none;padding:0;margin:0;">${reasonsHtml}</ul>
            </div>
          </div>

          <!-- Actions -->
          <div style="padding:8px 24px 24px;display:flex;flex-direction:column;gap:12px;">
            <button id="cybershield-leave" style="
              width:100%;background:#1d4ed8;color:#fff;font-weight:700;font-size:15px;
              padding:16px;border:none;border-radius:16px;cursor:pointer;
              box-shadow:0 4px 14px rgba(29,78,216,0.39);
              font-family:inherit;
            ">Safety First: Go Back</button>
            <div style="display:flex;align-items:center;justify-content:space-between;padding:0 4px;">
              <button id="cybershield-learn" style="
                font-size:13px;font-weight:600;color:#64748b;background:#f8fafc;
                border:none;border-radius:12px;padding:8px 16px;cursor:pointer;
                font-family:inherit;
              ">Learn More</button>
              <button id="cybershield-proceed" style="
                font-size:13px;font-weight:600;color:#94a3b8;background:transparent;
                border:none;padding:8px 16px;cursor:pointer;
                font-family:inherit;
              ">I trust this site</button>
            </div>
          </div>
        </div>
      </div>
    `;

    document.documentElement.appendChild(overlay);

    document.getElementById("cybershield-leave").addEventListener("click", () => {
      history.length > 1 ? history.back() : (location.href = "about:blank");
    });

    document.getElementById("cybershield-proceed").addEventListener("click", () => {
      overlay.remove();
      document.body.style.filter = "";
      document.body.style.pointerEvents = "";
    });

    const learnBtn = document.getElementById("cybershield-learn");
    if (learnBtn) {
      learnBtn.addEventListener("click", () => {
        window.open("https://www.phishing.org/what-is-phishing", "_blank");
      });
    }
  }
})();
