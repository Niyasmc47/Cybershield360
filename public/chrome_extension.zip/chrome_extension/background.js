// ── CyberShield 360 – Background Service Worker ──

// ═══════════════════════════════════════════════════════
// API KEYS — Add your keys here for enhanced detection
// ═══════════════════════════════════════════════════════
const API_KEYS = {
  GOOGLE_SAFE_BROWSING: "AIzaSyDMM720VNIHhZWfF87n8cEy5jyLF2tCDxg",   // Get free key: https://console.cloud.google.com/apis/library/safebrowsing.googleapis.com
  PHISHTANK: "",              // Get free key: https://phishtank.org/api_info.php
  VIRUSTOTAL: "270d5f153935afca6757fc25a807708aeacf0a34a9afa44ae4babf2ed7676834"              // Get free key: https://www.virustotal.com/gui/my-apikey
};

// Placeholder phishing domain list (local fallback)
const PHISHING_DOMAINS = [
  // ── Typosquatting / homograph fakes ──
  "paypa1.com", "g00gle.com", "faceb00k.com", "amaz0n-login.com",
  "secure-bankofamerica.com", "appleid-verify.com", "netflix-support.com",
  "micros0ft-login.com", "instagram-verify.com", "linkedln-login.com",

  // ── Known phishing / scam domains ──
  "login-microsoftonline.com", "outlook-logins.com", "microsoft365-login.com",
  "0ffice365.com", "office365-verify.com", "sharepoint-login.net",
  "accounts-google-signin.com", "google-account-verify.com", "gmail-login.net",
  "drive-google-share.com", "docs-google-verify.com",
  "secure-paypal-login.com", "paypal-support-center.com", "paypal-verify.net",
  "amazon-prime-verify.com", "amazon-security-alert.com", "amazon-order-update.com",
  "apple-id-support.com", "icloud-verify.com", "apple-support-verify.com",
  "facebook-security-check.com", "fb-login-verify.com", "meta-business-support.com",
  "instagram-support-verify.com", "ig-verify-account.com",
  "netflix-payment-update.com", "netflix-account-verify.com",
  "twitter-verify-account.com", "x-account-verify.com",
  "linkedin-verify-account.com", "linkedin-security-check.com",
  "github-security-alert.com", "github-verify-login.com",
  "dropbox-verify-account.com", "dropbox-share-document.com",
  "yahoo-account-verify.com", "yahoo-mail-login.com",
  "chase-secure-login.com", "wellsfargo-verify.com", "citibank-alert.com",
  "bankofamerica-secure.com", "usbank-verify.com", "capitalone-alert.com",
  "discord-nitro-free.com", "discord-gift-free.com", "discord-verify.com",
  "steam-community-trade.com", "steamcommunlty.com", "steampowered-verify.com",
  "roblox-free-robux.com", "roblox-verify.com",
  "twitch-drops-claim.com", "twitch-verify-account.com",
  "spotify-premium-free.com", "spotify-verify.com",
  "whatsapp-verify.com", "telegram-verify.com",
  "tiktok-verify-account.com", "tiktok-rewards.com",
  "snapchat-verify.com", "snap-score-boost.com",
  "dhl-tracking-delivery.com", "fedex-delivery-update.com", "ups-package-track.com",
  "usps-delivery-alert.com", "royalmail-delivery.com",
  "coinbase-verify.com", "binance-verify-account.com", "crypto-wallet-verify.com",
  "metamask-verify-wallet.com", "phantom-wallet-verify.com",
  "adobe-verify.com", "zoom-meeting-invite.com", "docusign-verify.com",
  "wetransfer-download.com", "onedrive-share-document.com",
  "walmart-reward.com", "target-gift-card.com", "costco-survey-reward.com",
  "free-iphone-winner.com", "prize-winner-claim.com", "lottery-winner-alert.com",
  "irs-tax-refund.com", "gov-tax-refund.com", "hmrc-refund-claim.com",

  // ── Scam / tech support / survey scams ──
  "your-computer-infected.com", "virus-alert-microsoft.com",
  "windows-defender-alert.com", "mcafee-renewal-alert.com",
  "norton-subscription-alert.com", "geeksquad-renewal.com",
  "customer-survey-reward.com", "amazon-shopper-reward.com"
];

// Popular domains used for typosquatting / homograph detection
const POPULAR_DOMAINS = [
  "google.com", "facebook.com", "amazon.com", "paypal.com", "apple.com",
  "microsoft.com", "netflix.com", "instagram.com", "linkedin.com",
  "bankofamerica.com", "twitter.com", "github.com", "dropbox.com", "yahoo.com"
];

// Character substitution map for homograph detection
const CHAR_SUBS = {
  "0": "o", "1": "l", "3": "e", "4": "a", "5": "s",
  "7": "t", "@": "a", "!": "i", "|": "l",
  "rn": "m", "vv": "w", "cl": "d"
};

// ── Scoring helpers ──

// Suspicious keyword patterns — brand + scam keyword in the domain
const SCAM_KEYWORDS = [
  "verify", "secure", "login", "signin", "alert", "update", "confirm",
  "suspend", "restore", "unlock", "recover", "billing", "refund",
  "free-robux", "free-vbucks", "gift-card", "prize", "winner", "reward"
];
const BRAND_KEYWORDS = [
  "google", "facebook", "meta", "apple", "icloud", "microsoft", "office365",
  "amazon", "paypal", "netflix", "instagram", "twitter", "linkedin", "github",
  "dropbox", "yahoo", "chase", "wellsfargo", "citibank", "bankofamerica",
  "discord", "steam", "roblox", "twitch", "spotify", "whatsapp", "telegram",
  "tiktok", "snapchat", "coinbase", "binance", "metamask", "dhl", "fedex",
  "ups", "usps", "irs", "hmrc", "norton", "mcafee", "geeksquad"
];

function isInPhishingList(domain) {
  // Exact match
  if (PHISHING_DOMAINS.includes(domain)) return true;

  // Pattern match: domain contains a brand keyword + scam keyword
  const lower = domain.toLowerCase();
  const hasBrand = BRAND_KEYWORDS.some((b) => lower.includes(b));
  const hasScam = SCAM_KEYWORDS.some((s) => lower.includes(s));
  return hasBrand && hasScam;
}

function normalizeDomain(domain) {
  let normalized = domain.toLowerCase();
  for (const [fake, real] of Object.entries(CHAR_SUBS)) {
    normalized = normalized.split(fake).join(real);
  }
  return normalized;
}

function looksSimilarToPopular(domain) {
  const cleaned = domain.replace(/^www\./, "");
  const normalized = normalizeDomain(cleaned);

  for (const popular of POPULAR_DOMAINS) {
    if (cleaned === popular) continue;
    if (normalized === popular) return popular;
    if (levenshtein(cleaned, popular) <= 2) return popular;
  }
  return null;
}

function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
}

// Placeholder – replace with real WHOIS / API lookup later
function isNewlyCreatedDomain(_domain) {
  return false;
}

// ── Hosting / URL heuristics ──

const SUSPICIOUS_HOSTS = [
  "trycloudflare.com",
  "ngrok.io", "ngrok-free.app", "ngrok.app",
  "serveo.net", "localhost.run", "loca.lt",
  "telebit.cloud", "pagekite.me",
  "workers.dev", "pages.dev",
  "netlify.app", "vercel.app",
  "glitch.me", "replit.co", "repl.co",
  "herokuapp.com", "firebaseapp.com", "web.app",
  "000webhostapp.com", "weebly.com", "blogspot.com",
  "sites.google.com"
];

function isOnSuspiciousHost(hostname) {
  return SUSPICIOUS_HOSTS.some(
    (h) => hostname === h || hostname.endsWith("." + h)
  );
}

function hasSuspiciousSubdomain(hostname) {
  const parts = hostname.split(".");
  if (parts.length < 3) return false;
  const sub = parts.slice(0, -2).join(".");
  const hyphenParts = sub.split("-");
  return sub.length > 25 || hyphenParts.length >= 4;
}

const STANDARD_PORTS = ["", "80", "443"];

function isIPAddress(hostname) {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname) ||
         hostname === "localhost" ||
         hostname.startsWith("[");
}

function isNonStandardPort(port) {
  return port && !STANDARD_PORTS.includes(port);
}

// ═══════════════════════════════════════════════════════
// THREAT INTELLIGENCE APIs
// ═══════════════════════════════════════════════════════

// In-memory cache: url/domain → { result, timestamp }
const apiCache = new Map();
const CACHE_TTL = 10 * 60 * 1000; // 10 minutes

function getCached(key) {
  const entry = apiCache.get(key);
  if (entry && Date.now() - entry.timestamp < CACHE_TTL) return entry.result;
  apiCache.delete(key);
  return null;
}

function setCache(key, result) {
  apiCache.set(key, { result, timestamp: Date.now() });
}

// ── Google Safe Browsing API ──
async function checkGoogleSafeBrowsing(url) {
  if (!API_KEYS.GOOGLE_SAFE_BROWSING) return null;

  const cacheKey = "gsb:" + url;
  const cached = getCached(cacheKey);
  if (cached !== null) return cached;

  try {
    const response = await fetch(
      `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${API_KEYS.GOOGLE_SAFE_BROWSING}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          client: { clientId: "cybershield360", clientVersion: "1.0.0" },
          threatInfo: {
            threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
            platformTypes: ["ANY_PLATFORM"],
            threatEntryTypes: ["URL"],
            threatEntries: [{ url }]
          }
        })
      }
    );
    const data = await response.json();
    const isThreat = !!(data.matches && data.matches.length > 0);
    const threatType = isThreat ? data.matches[0].threatType : null;
    const result = { flagged: isThreat, source: "Google Safe Browsing", threatType };
    setCache(cacheKey, result);
    return result;
  } catch (e) {
    console.warn("CyberShield 360: Google Safe Browsing API error", e);
    return null;
  }
}

// ── PhishTank API ──
async function checkPhishTank(url) {
  if (!API_KEYS.PHISHTANK) return null;

  const cacheKey = "pt:" + url;
  const cached = getCached(cacheKey);
  if (cached !== null) return cached;

  try {
    const body = new URLSearchParams({
      url: url,
      format: "json",
      app_key: API_KEYS.PHISHTANK
    });
    const response = await fetch("https://checkurl.phishtank.com/checkurl/", {
      method: "POST",
      body
    });
    const data = await response.json();
    const isPhish = !!(data.results && data.results.in_database && data.results.valid);
    const result = { flagged: isPhish, source: "PhishTank" };
    setCache(cacheKey, result);
    return result;
  } catch (e) {
    console.warn("CyberShield 360: PhishTank API error", e);
    return null;
  }
}

// ── URLhaus (abuse.ch) – FREE, no API key needed ──
async function checkURLhaus(url) {
  const domain = new URL(url).hostname;
  const cacheKey = "uh:" + domain;
  const cached = getCached(cacheKey);
  if (cached !== null) return cached;

  try {
    const body = new URLSearchParams({ host: domain });
    const response = await fetch("https://urlhaus-api.abuse.ch/v1/host/", {
      method: "POST",
      body
    });
    const data = await response.json();
    const isMalware = data.query_status === "no_results" ? false : true;
    const result = {
      flagged: isMalware,
      source: "URLhaus (abuse.ch)",
      urlCount: data.urls ? data.urls.length : 0
    };
    setCache(cacheKey, result);
    return result;
  } catch (e) {
    console.warn("CyberShield 360: URLhaus API error", e);
    return null;
  }
}

// ── VirusTotal API ──
async function checkVirusTotal(url) {
  if (!API_KEYS.VIRUSTOTAL) return null;

  const cacheKey = "vt:" + url;
  const cached = getCached(cacheKey);
  if (cached !== null) return cached;

  try {
    // Step 1: Submit URL for scanning
    const scanResponse = await fetch("https://www.virustotal.com/api/v3/urls", {
      method: "POST",
      headers: {
        "x-apikey": API_KEYS.VIRUSTOTAL,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({ url })
    });
    const scanData = await scanResponse.json();

    // Step 2: Get the analysis using the URL ID
    const urlId = btoa(url).replace(/=/g, "");
    const reportResponse = await fetch(
      `https://www.virustotal.com/api/v3/urls/${urlId}`,
      { headers: { "x-apikey": API_KEYS.VIRUSTOTAL } }
    );
    const report = await reportResponse.json();

    const stats = report.data?.attributes?.last_analysis_stats;
    const malicious = stats ? (stats.malicious || 0) + (stats.suspicious || 0) : 0;
    const result = {
      flagged: malicious > 0,
      source: "VirusTotal",
      maliciousCount: malicious,
      totalEngines: stats ? Object.values(stats).reduce((a, b) => a + b, 0) : 0
    };
    setCache(cacheKey, result);
    return result;
  } catch (e) {
    console.warn("CyberShield 360: VirusTotal API error", e);
    return null;
  }
}

// ── Run all API checks in parallel ──
async function checkThreatAPIs(url) {
  const checks = [
    checkURLhaus(url),          // Always runs (free, no key)
    checkGoogleSafeBrowsing(url),
    checkPhishTank(url),
    checkVirusTotal(url)
  ];

  const results = await Promise.allSettled(checks);
  const apiResults = [];

  for (const r of results) {
    if (r.status === "fulfilled" && r.value && r.value.flagged) {
      apiResults.push(r.value);
    }
  }

  return apiResults;
}

// ═══════════════════════════════════════════════════════
// MAIN ANALYSIS (local heuristics – synchronous)
// ═══════════════════════════════════════════════════════

function analyzeUrl(url, pageData) {
  const parsed = new URL(url);
  const domain = parsed.hostname.replace(/^www\./, "");
  const protocol = parsed.protocol;
  const port = parsed.port;

  let score = 0;
  const reasons = [];

  // 1. Local phishing list check
  if (isInPhishingList(domain)) {
    score += 5;
    reasons.push("Domain found in known phishing list");
  }

  // 2. Homograph / typosquatting check
  const similarTo = looksSimilarToPopular(domain);
  if (similarTo) {
    score += 2;
    reasons.push(`Domain looks similar to ${similarTo}`);
  }

  // 3. Login / password form detected
  if (pageData && pageData.hasPasswordField) {
    score += 2;
    reasons.push("Page contains a password/login form");
  }

  // 4. HTTP instead of HTTPS
  if (protocol === "http:") {
    score += 1;
    reasons.push("Site does not use HTTPS");
  }

  // 5. Newly created domain (placeholder)
  if (isNewlyCreatedDomain(domain)) {
    score += 3;
    reasons.push("Domain appears to be newly created");
  }

  // 6. Brand impersonation
  const impersonated = pageData && pageData.impersonatedBrand;
  if (impersonated) {
    score += 4;
    reasons.push(`Page impersonates ${pageData.impersonatedBrand} but is not on its official domain`);
  }

  // 7. Suspicious tunneling / free hosting
  if (isOnSuspiciousHost(domain)) {
    score += 2;
    reasons.push("Site is hosted on a suspicious tunneling/free hosting service");
  }

  // 8. Long or random subdomain
  if (hasSuspiciousSubdomain(domain)) {
    score += 1;
    reasons.push("Domain has a suspiciously long or random subdomain");
  }

  // 9. Raw IP — only with phishing signals
  const hasPhishingSignals = impersonated || (pageData && pageData.hasPasswordField);
  if (isIPAddress(domain) && hasPhishingSignals) {
    score += 3;
    reasons.push("Site is hosted on a raw IP address with phishing content");
  }

  // 10. Non-standard port — only with phishing signals
  if (isNonStandardPort(port) && hasPhishingSignals) {
    score += 1;
    reasons.push(`Site uses non-standard port :${port}`);
  }

  // 11. Form submits to a different domain
  if (pageData && pageData.suspiciousFormAction) {
    score += 2;
    reasons.push("Form submits data to a different domain");
  }

  const finalScore = Math.max(1, Math.min(10, score === 0 ? 1 : score));

  let status;
  if (finalScore <= 3) status = "Safe";
  else if (finalScore <= 6) status = "Suspicious";
  else status = "Dangerous";

  return { domain, score: finalScore, status, reasons, apiChecked: false };
}

// Enhance a result with API findings
function enhanceWithAPIs(result, apiResults) {
  let extraScore = 0;
  const extraReasons = [];

  for (const api of apiResults) {
    if (api.source === "Google Safe Browsing") {
      extraScore += 5;
      const type = api.threatType === "SOCIAL_ENGINEERING" ? "phishing" : api.threatType.toLowerCase().replace(/_/g, " ");
      extraReasons.push(`⛔ Flagged by Google Safe Browsing (${type})`);
    } else if (api.source === "PhishTank") {
      extraScore += 5;
      extraReasons.push("⛔ Confirmed phishing site by PhishTank");
    } else if (api.source === "URLhaus (abuse.ch)") {
      extraScore += 4;
      extraReasons.push(`⛔ Listed in URLhaus malware database (${api.urlCount} malicious URLs)`);
    } else if (api.source === "VirusTotal") {
      extraScore += 4;
      extraReasons.push(`⛔ Flagged by ${api.maliciousCount}/${api.totalEngines} VirusTotal engines`);
    }
  }

  const newRawScore = result.score + extraScore;
  const newScore = Math.max(1, Math.min(10, newRawScore));

  let status;
  if (newScore <= 3) status = "Safe";
  else if (newScore <= 6) status = "Suspicious";
  else status = "Dangerous";

  return {
    ...result,
    score: newScore,
    status,
    reasons: [...result.reasons, ...extraReasons],
    apiChecked: true
  };
}

// ═══════════════════════════════════════════════════════
// PRE-LOAD URL CHECK
// ═══════════════════════════════════════════════════════

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;

  try {
    const result = analyzeUrl(details.url, null);

    if (result.score >= 8) {
      setTimeout(() => {
        chrome.tabs.sendMessage(details.tabId, {
          type: "URL_PRE_CHECK",
          result
        }).catch(() => {});
      }, 100);
    }
  } catch { /* invalid URL */ }
});

// ═══════════════════════════════════════════════════════
// MESSAGE HANDLING
// ═══════════════════════════════════════════════════════

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "PAGE_DATA") {
    // Phase 1: Instant local analysis
    const localResult = analyzeUrl(message.url, message.data);
    const tabId = _sender.tab?.id;

    if (tabId) {
      chrome.storage.local.set({ [`lastResult_${tabId}`]: localResult });
    }

    // Send local result immediately so user sees something fast
    if (_sender.tab && _sender.tab.id) {
      chrome.tabs.sendMessage(_sender.tab.id, {
        type: "ANALYSIS_RESULT",
        result: localResult
      }).catch(() => {});
    }

    if (localResult.score >= 8) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "data:image/svg+xml," + encodeURIComponent(
          '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48"><rect width="48" height="48" fill="#dc2626" rx="8"/><text x="24" y="34" text-anchor="middle" fill="#fff" font-size="28" font-weight="bold" font-family="Arial">!</text></svg>'
        ),
        title: "🚨 CRITICAL THREAT DETECTED",
        message: `⚠️ HIGH RISK: ${localResult.domain}\nRisk Score: ${localResult.score}/10\n\nDO NOT enter credentials or personal info!`,
        priority: 2
      });
    }

    // Phase 2: Async API checks — enhance the result
    checkThreatAPIs(message.url).then((apiResults) => {
      if (apiResults.length === 0) {
        // No API flags — just mark as API-checked
        const checkedResult = { ...localResult, apiChecked: true };
        if (tabId) {
          chrome.storage.local.set({ [`lastResult_${tabId}`]: checkedResult });
        }
        if (_sender.tab && _sender.tab.id) {
          chrome.tabs.sendMessage(_sender.tab.id, {
            type: "ANALYSIS_RESULT",
            result: checkedResult
          }).catch(() => {});
        }
        return;
      }

      const enhancedResult = enhanceWithAPIs(localResult, apiResults);
      if (tabId) {
        chrome.storage.local.set({ [`lastResult_${tabId}`]: enhancedResult });
      }

      // Update content script with new score
      if (_sender.tab && _sender.tab.id) {
        chrome.tabs.sendMessage(_sender.tab.id, {
          type: "ANALYSIS_RESULT",
          result: enhancedResult
        }).catch(() => {});
      }

      // Show notification if risk score is above 8
      if (enhancedResult.score > 8) {
        chrome.notifications.create({
          type: "basic",
          iconUrl: "data:image/svg+xml," + encodeURIComponent(
            '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48"><rect width="48" height="48" fill="#dc2626" rx="8"/><text x="24" y="34" text-anchor="middle" fill="#fff" font-size="28" font-weight="bold" font-family="Arial">!</text></svg>'
          ),
          title: "🚨 CRITICAL THREAT DETECTED",
          message: `⚠️ HIGH RISK: ${enhancedResult.domain}\nRisk Score: ${enhancedResult.score}/10\n\nDO NOT enter credentials or personal info!`,
          priority: 2
        });
      }
    });

    sendResponse({ success: true });
  }

  if (message.type === "GET_RESULT") {
    const tabId = message.tabId;
    if (tabId) {
      chrome.storage.local.get(`lastResult_${tabId}`, (data) => {
        sendResponse(data[`lastResult_${tabId}`] || null);
      });
    } else {
      sendResponse(null);
    }
    return true;
  }
});

// ── Optional: future Flask backend integration ──
// async function analyzeWithBackend(domain) {
//   const response = await fetch("http://localhost:5000/api/analyze", {
//     method: "POST",
//     headers: { "Content-Type": "application/json" },
//     body: JSON.stringify({ domain })
//   });
//   return response.json();
// }
