// ── CyberShield 360 – Popup Script ──

const REASON_DETAILS = {
  "Domain found in known phishing list": "This domain matches a known phishing or scam website.",
  "Page contains a password/login form": "A login form was detected which could be used to steal credentials.",
  "Site does not use HTTPS": "Your data is not encrypted and could be intercepted by attackers.",
  "Site is hosted on a raw IP address with phishing content": "Legitimate sites use domain names, not raw IP addresses.",
  "Site is hosted on a suspicious tunneling/free hosting service": "Tunneling services are commonly abused to host phishing pages.",
  "Domain has a suspiciously long or random subdomain": "Phishing sites often use long random subdomains to hide their identity.",
  "Form submits data to a different domain": "Your credentials may be sent to an attacker-controlled server.",
  "Domain appears to be newly created": "Newly registered domains are frequently used for scams."
};

function getReasonDetail(reason) {
  for (const [key, desc] of Object.entries(REASON_DETAILS)) {
    if (reason.includes(key) || key.includes(reason)) return desc;
  }
  if (reason.includes("impersonates")) return "This page mimics a trusted brand to trick you.";
  if (reason.includes("looks similar")) return "The domain uses deceptive characters to mimic a trusted site.";
  if (reason.includes("non-standard port")) return "Legitimate websites rarely use unusual port numbers.";
  if (reason.startsWith("⛔")) return "Confirmed threat by an external security intelligence service.";
  return "This indicator suggests potential risk.";
}

function getDotClass(reason) {
  if (reason.startsWith("⛔")) return "dot-red";
  if (reason.includes("phishing") || reason.includes("impersonates") || reason.includes("Dangerous"))
    return "dot-red";
  if (reason.includes("password") || reason.includes("HTTPS") || reason.includes("form"))
    return "dot-orange";
  return "dot-blue";
}

// Map score 1–10 to how many segments are filled + their colors
function updateRiskBar(score) {
  const segments = [
    document.getElementById("seg1"),
    document.getElementById("seg2"),
    document.getElementById("seg3"),
    document.getElementById("seg4"),
    document.getElementById("seg5")
  ];

  const colors = ["seg-green", "seg-yellow", "seg-orange", "seg-red", "seg-darkred"];
  const filled = Math.ceil(score / 2); // 1-2 → 1, 3-4 → 2, 5-6 → 3, 7-8 → 4, 9-10 → 5

  segments.forEach((seg, i) => {
    seg.className = "risk-segment " + (i < filled ? colors[i] : "seg-empty");
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const loadingEl = document.getElementById("loading");
  const resultsEl = document.getElementById("results");
  const domainEl = document.getElementById("domain");
  const threatCard = document.getElementById("threat-card");
  const threatTitle = document.getElementById("threat-title");
  const threatDesc = document.getElementById("threat-desc");
  const iconSafe = document.getElementById("icon-safe");
  const iconWarning = document.getElementById("icon-warning");
  const iconDanger = document.getElementById("icon-danger");
  const riskLabel = document.getElementById("risk-label");
  const scoreText = document.getElementById("score-text");
  const reasonsList = document.getElementById("reasons-list");
  const noIssues = document.getElementById("no-issues");
  const apiStatus = document.getElementById("api-status");

  // Get current tab to fetch tab-specific result
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tabId = tabs[0]?.id;
    chrome.runtime.sendMessage({ type: "GET_RESULT", tabId }, (result) => {
      loadingEl.classList.add("hidden");
      resultsEl.classList.remove("hidden");

      if (!result) {
        domainEl.textContent = "No data yet";
        threatTitle.textContent = "Waiting…";
        threatDesc.textContent = "Visit a website to start analysis.";
        return;
      }

      domainEl.textContent = result.domain;
      scoreText.textContent = result.score + " / 10";
      updateRiskBar(result.score);

      // Theme based on status
      iconSafe.classList.add("hidden");
      iconWarning.classList.add("hidden");
      iconDanger.classList.add("hidden");

      if (result.status === "Safe") {
        threatCard.className = "threat-card threat-safe";
        iconSafe.classList.remove("hidden");
        threatTitle.textContent = "Site is Safe";
        threatDesc.textContent = "No significant risks were detected on this page.";
        riskLabel.textContent = "Safe";
        riskLabel.className = "risk-value safe";
      } else if (result.status === "Suspicious") {
        threatCard.className = "threat-card threat-suspicious";
        iconWarning.classList.remove("hidden");
        threatTitle.textContent = "Caution Advised";
        threatDesc.textContent = "Some indicators suggest this page may not be fully trustworthy.";
        riskLabel.textContent = "Medium Risk";
        riskLabel.className = "risk-value suspicious";
      } else {
        threatCard.className = "threat-card threat-dangerous";
        iconDanger.classList.remove("hidden");
        threatTitle.textContent = "Threat Detected";
        threatDesc.textContent = "We've found potential risks that may compromise your privacy.";
        riskLabel.textContent = "High Risk";
        riskLabel.className = "risk-value dangerous";
      }

      // Reasons
      reasonsList.innerHTML = "";
      if (result.reasons.length === 0) {
        noIssues.classList.remove("hidden");
      } else {
        result.reasons.forEach((reason) => {
          const li = document.createElement("li");
          if (reason.startsWith("⛔")) li.classList.add("api-flag");

          const dot = document.createElement("div");
          dot.className = "dot " + getDotClass(reason);

          const content = document.createElement("div");
          content.className = "reason-content";

          const title = document.createElement("span");
          title.className = "reason-title";
          title.textContent = reason;

          const desc = document.createElement("span");
          desc.className = "reason-desc";
          desc.textContent = getReasonDetail(reason);

          content.appendChild(title);
          content.appendChild(desc);
          li.appendChild(dot);
          li.appendChild(content);
          reasonsList.appendChild(li);
        });
      }

      // API status
      if (result.apiChecked) {
        apiStatus.textContent = "✔ Threat databases checked";
        apiStatus.className = "api-status checked";
      } else {
        apiStatus.textContent = "⏳ Checking threat databases…";
        apiStatus.className = "api-status pending";
      }
    });
  });
});
